# Dashboard pabrik PT. SMM - revisi 15

12 November 2026. Buka Dashboard_Plant_3D.html secara lokal di Chrome/Edge. Jika versi lama masih terbuka, tekan Ctrl+R. HTML sudah berisi pustaka, model dan gambar sumber; tidak membutuhkan internet/server.

## Teks dan informasi yang dapat disembunyikan

- **Teks 3D** pada bagian bawah model menampilkan atau menyembunyikan nama area, nama mesin, dan nomor pallet. Penanda area berbentuk bersudut dengan gradien biru, simbol berlian dan garis warna zona. Label mesin berisi nama, ID visual dan status singkat.
- **Info & legenda** menampilkan atau menyembunyikan keterangan tampilan, legenda warna zona serta legenda status. Tombol **Sembunyikan ×** menutup panel yang sama.
- Keduanya tersembunyi saat pertama dibuka. Pilihan disimpan di browser bila penyimpanan tersedia. Klik objek tetap membuka detail ketika label disembunyikan.
- Seret untuk memutar, scroll untuk zoom, klik kanan untuk menggeser. Pilih area untuk fokus, lalu Reset untuk kembali ke seluruh pabrik.

## Detail mesin dan tekstur — revisi 15

Perbesar model atau gunakan Fokus pada objek untuk melihat detail mesin:

- Jetflow: serat stainless halus, sambungan ujung bejana, flange pintu, gasket gelap, baut segi enam, engsel, pipa servis, dan list aluminium pada platform.
- Kabinet mesin/finishing/boiler: cat satin, sambungan panel, list aluminium, pengikat, gagang servis, kisi ventilasi, dan panel kontrol.
- Tangki: pita sambungan metal, tutup inspeksi, gasket, baut, dan pipa servis.
- LA dispensing lantai 2 dan 3: pita tangki, header/pipa distribusi, lantai servis berpola antiselip, dan panel kontrol. Seluruh tambahan mengikuti lantai induknya.

Tekstur dibuat lokal dan tertanam dalam kode HTML; tidak membutuhkan internet. Detail memakai geometri bersama agar ribuan komponen tidak menjadi ribuan objek gambar terpisah.

Layar kecil pada model hanya menggambarkan panel HMI dengan kolom kosong. Dial memakai tanda skala tanpa jarum atau nilai proses. Pembacaan/status monitoring tetap berasal dari panel dashboard dan sumber data/demo, bukan dekorasi model.

Detail ini ilustrasi industrial berdasarkan bentuk generik dan referensi gaya, bukan replika teknik mesin aktual. Bentuk spesifik memerlukan foto atau gambar mesin terkait. Koordinat mesin, arah jetflow, lantai pastel, glow tepi, latar waktu WIB, dan layout/data Greige tetap dipertahankan.

## Lantai, mesin, dan garis tepi — revisi 15

Lantai memakai warna pastel rata tanpa tekstur berbintik: mint, biru muda, lavender, krem, dan abu kebiruan. Seluruh warna berada pada satu permukaan lantai yang menyambung, tanpa trotoar atau pelat zona bertingkat. Batas pembagian area dan posisi objek tetap mengikuti layout yang sudah ada.

Mesin memakai bodi silver-putih, penutup putih terang dengan sambungan panel tipis, dan aksen cyan ringan pada panel, layar, dan cincin bejana. Tepi kabinet sedikit membulat untuk menangkap pencahayaan. Bejana dan tangki memakai material metal; atap boiler/utilitas tetap slate gelap. Bentuk masih model sederhana, bukan model teknik mesin aktual.

Garis luar pabrik sekarang berupa jalur tertutup putih-cyan dengan halo lembut, mengikuti seluruh sudut batas pabrik. Garis antarzona lebih tipis. Setiap garis terdiri dari inti putih, tepi cyan, dan halo yang memudar ke luar. Intensitas dapat diatur melalui **Info & legenda → Glow area**; tombol yang sama menyembunyikan glow batas zona dan tepi luar sekaligus. Warna lantai tetap terlihat saat glow dimatikan. Memilih area meredupkan garis zona lain dan mempertahankan garis luar sebagai konteks.

Aktifkan **Teks 3D** untuk label area/mesin dan **Info & legenda** untuk keterangan. Keduanya tetap bisa disembunyikan. Jika HTML sudah terbuka, muat ulang dengan Ctrl+R agar revisi 15 muncul.

## Gaya pastel dan latar mengikuti waktu

Tampilan mengikuti referensi masterplan pastel: zona mint, biru muda, lavender, krem, dan abu kebiruan; mesin silver/abu muda dengan aksen cyan ringan. Kartu info memakai nuansa kaca lembut, label area bersudut bertepi cyan, dan garis dekoratif tipis berada di belakang model. Seluruh perubahan tema waktu dibatasi pada tampilan 3D.

Latar berubah otomatis sesuai jam komputer yang dikonversi ke WIB (Asia/Jakarta):

| Waktu WIB | Suasana |
|---|---|
| 19.00–05.30 | Biru donker |
| 05.30–07.00 | Transisi halus dari donker ke putih lembut |
| 07.00–16.30 | Putih lembut / biru sangat muda |
| 16.30–19.00 | Transisi halus dari putih lembut ke donker |

Penghitungan menggunakan waktu aktual, bukan lama halaman terbuka. Setelah tab kembali aktif atau komputer bangun dari sleep, warna langsung diselaraskan dengan waktu saat itu. Palet diperbarui setiap 30 detik dengan crossfade; preferensi sistem mengurangi gerakan dihormati. Pencahayaan model menyesuaikan ringan pada malam hari, sementara status operasi tetap berasal dari data/demo.

Buka **Info & legenda → Latar 3D** untuk memilih **Pratinjau siang** atau **Pratinjau malam**. Pilih **Waktu aktual · WIB** untuk kembali otomatis. Pratinjau tidak mengubah jam dashboard dan tidak disimpan saat halaman dimuat ulang; halaman selalu mulai dalam mode waktu aktual.

Jadwal ini adalah pengaturan visual tetap WIB, bukan perhitungan terbit/terbenam matahari berdasarkan lokasi atau cuaca. Akurasi waktu mengikuti jam komputer.

Glow area mengatur cahaya batas zona; warna lantai tetap terlihat saat glow dimatikan. Lapisan denah dapat diaktifkan untuk membandingkan posisi dengan DWG.

## Greige lantai 1 terbaru

Susunan mengikuti simbol pallet hijau pada DENAH PALETE KAIN GREIGE TERBARU-LANTAI 1.pdf. G001–G502 adalah ID visual sementara yang disetujui pengguna; urut kiri ke kanan lalu baris atas ke bawah pada PDF. Posisi didaftarkan ke model menggunakan Continuous 1, Continuous 2 dan Lafer SPA dengan satu skala dan rotasi 90 derajat, sehingga bentuk baris, jarak relatif dan lorong tidak diregangkan.

PDF memiliki 502 simbol, tetapi tiga pasangan bertumpuk. Model menampilkan **499 posisi unik**, sedangkan **G076, G078 dan G080 menunggu koreksi posisi pengguna**. Ketiganya tetap ada dalam daftar ID, namun tidak dibuat sebagai pallet tersendiri pada 3D. Di panel Greige, buka bagian 3 ID menunggu koreksi untuk melihat pasangan G076/G075, G078/G077 dan G080/G079.

Kode lama tetap tersedia pada denah arsip, dan lantai atas tetap menggunakan kode asli. Data roll G001–G502 disimpan terpisah dari daftar lama. Tidak ada pemindahan atau pemasangan kode otomatis. Pilih denah yang sesuai sebelum impor atau ekspor; daftar lain tetap tersimpan. Lihat PANDUAN_GREIGE.md.

## Status mesin

Nyala hijau, Stop amber, Maintenance biru, Downtime merah, Belum terhubung abu tanpa glow status. Aktifkan demo untuk contoh status dan nilai simulasi. Belum ada koneksi PLC atau sistem stok langsung. Glow status terpisah dari aksen cyan dekoratif dan warna zona.

## Berkas

- Dashboard_Plant_3D.html: dashboard mandiri.
- Lokasi_Greige_Lantai1_Terbaru.csv: G001–G502, termasuk status tiga posisi yang menunggu koreksi.
- Lokasi_Gudang_Greige.csv: register kode lama, tidak diubah.
- Template_Roll_Greige.csv: header untuk impor data roll; isi kode sesuai daftar yang sedang dibuka.
- Inventaris_Layout_Pabrik.csv: inventaris mesin dan material.
- ZIP berisi HTML, panduan dan semua CSV di atas. Versi sebelumnya ada di archive_v14_dwg.

Model mesin tetap konseptual. Pemetaan PDF adalah registrasi gambar, bukan survei lapangan. Lihat VERIFIKASI.md untuk hasil pengujian dan batas pemeriksaan browser.
