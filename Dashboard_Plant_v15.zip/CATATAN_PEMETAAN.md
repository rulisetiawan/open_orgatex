# Tambahan revisi 15 — 12 November 2026

Perubahan pada tekstur material dan detail mesin generik: list aluminium, sambungan panel, pengikat, flange/gasket, ventilasi, pipa servis, dan panel kontrol. Detail terpasang pada footprint lama dan mewarisi identitas serta lantai aset induk. Tidak ada perpindahan mesin, perubahan arah jetflow, atau migrasi data Greige.

Area mini dyeing A233 dan area bakar bulu A234 berhimpit dengan sisi dinding Gudang barang jadi A220 pada layout yang sudah ada. Ray dari sisi luar panel dapat mengenai dinding terlebih dahulu; posisi dinding dan objek tidak digeser pada revisi visual ini. Pemilihan melalui inventaris tetap tersedia.

Detail bukan dokumentasi fabrikasi. Skala dial, layar, baut, dan pipa hanya memperjelas tampilan industrial; tidak dianggap sebagai spesifikasi atau nilai proses aktual.

# Tambahan revisi 14 — 12 November 2026

Penyempurnaan visual lantai pastel rata, kabinet silver-putih bertepi halus, dan garis putih-cyan menyambung. Garis luar mengikuti 28 titik batas pabrik sumber. Batas zona yang keluar dari pelat dipotong pada batas pelat; garis berimpit tidak digambar dua kali.

Koordinat dan footprint 230 objek, arah 87 jetflow, posisi pembatas/jalan, layout Greige lantai 1, serta penyimpanan data roll tetap sama dengan R13. Pallet G076, G078, G080 tetap menunggu koreksi posisi pengguna; tidak dibuatkan posisi baru.

# Tambahan revisi 13 - 12 November 2026

Perubahan ini hanya pada palet, dekorasi latar, label/kartu, dan pencahayaan. Koordinat mesin, arah jetflow, susunan PDF Greige, dua penyimpanan roll, serta ID yang menunggu koreksi tetap sama. Greige tetap 499 posisi unik dan 3 ID menunggu koreksi: G076, G078, G080.

Suasana memakai jam perangkat dengan zona Asia/Jakarta. Transisi visual tetap: 05.30–07.00 pagi dan 16.30–19.00 sore. Mode pratinjau siang/malam tidak mengubah waktu data atau status mesin.

# Tambahan revisi 12 - 12 November 2026

Lantai 1 Greige memakai ekstraksi 502 persegi hijau pada PDF terbaru. Satu skala 0,3446816031 dan rotasi 90 derajat didaftarkan terhadap pusat Continuous 1/2 dan Lafer SPA. Residual maksimum ketiga acuan sekitar 0,01518 satuan koordinat model; ini kecocokan gambar, bukan toleransi survei. Simbol PDF, ID sementara, hash sumber dan transformasi disimpan di cad_reference/revision12/ground-register.json.

Ada 499 posisi unik. G076/G078/G080 bertumpuk dengan G075/G077/G079 dan menunggu koreksi pengguna; ketiganya tidak digandakan di 3D. Tidak ada penempatan baru yang dikarang. Kode lama dan koordinat lantai atas tetap tersedia. Warna zona Greige disesuaikan untuk mencakup susunan PDF terbaru. Mesin dan orientasi jetflow tidak dipindahkan.

Catatan revisi sebelumnya di bawah adalah riwayat.

# Tambahan revisi 11 - 12 November 2026

Seluruh bidang sembilan zona navigasi diberi warna penuh pada material lantai yang sama. Tidak ada lantai baru bertumpuk atau perubahan alur jalan. Zona yang bertumpuk diberi prioritas sesuai urutan poligon, sehingga warna tidak dicampur menjadi lebih gelap. Dimensi dan posisi 230 objek, 87 arah jetflow, nomor Greige, serta pemisahan tingkat dosing tetap sama.

Representasi mesin diperbarui menjadi silver/abu muda dengan panel gelap, trim cyan, ventilasi sederhana dan pita/cincin pada bejana. Ini perubahan gaya visual konseptual. Tidak ada klaim bahwa detail tambahan berasal dari pengukuran mesin aktual. Aksen cyan bersifat dekoratif dan tidak terkait status operasi. Catatan revisi sebelumnya di bawah adalah riwayat, bukan spesifikasi warna aktif.

# Tambahan revisi 10 - 12 November 2026

Glow batas memakai sembilan poligon navigasi dari layout yang sudah ada. Pembagian kelompok inventaris tetap 19 area, dan jumlah objek tetap 230. Tidak ada pemindahan mesin, perubahan nomor/posisi Greige, atau perubahan lantai. Garis yang bertumpuk dibagi agar tidak menggandakan cahaya. Label Produksi depan digeser sedikit di dalam zona untuk menghindari area dosing; geometri peralatan tidak berubah. Foto referensi digunakan sebagai arah gaya cahaya lembut, bukan untuk mengganti denah DWG.

# Revisi 9 - warna UI, glow mesin dan keterangan Greige

Koordinat pabrik, nomor Greige, material bodi dan lantai sama dengan revisi 8. Perubahan hanya pada warna antarmuka, efek status mesin dan penyajian status lokasi Greige. factory-layout.json, greige-layout.js, plant-surfaces.js dan flat-industrial-style.js identik dengan arsip revisi 8.

Empat status mesin disimulasikan hanya jika demo diaktifkan. Penambahan ini tidak membuat sambungan PLC atau menyimpulkan kondisi mesin aktual. Data roll tetap berasal dari CSV/localStorage. Kategori kosong menyatakan 0 roll dalam daftar impor, bukan konfirmasi fisik. Fasilitas/penanda merah tetap dilarang menerima roll. Di 3D, warna lokasi berada pada strip kecil; badan pallet netral.

Catatan di bawah merupakan riwayat revisi sebelumnya.

---

# Revisi 8 - klarifikasi warna flat

Hanya material dan aksen antarmuka yang berubah dari revisi 7. Bodi netral dengan panel/detail berwarna lembut; bukan monokrom penuh. factory-layout.json, greige-layout.js, dan plant-surfaces.js sama dengan arsip revisi 7. Posisi/nomor Greige, seluruh bentuk data aset, permukaan lantai yang menerus dan marka datar tetap.

Catatan revisi 7 dan sebelumnya di bawah adalah riwayat. Tema aktif dijelaskan pada WARNA_MESIN.md.

---

# Cakupan perubahan revisi 7

Hanya tema monokrom dan penyajian permukaan lantai/jalan. factory-layout.json dan greige-layout.js identik dengan arsip revisi 6. Susunan 502 pallet dari PDF terbaru belum diterapkan atas instruksi pengguna untuk menunda perubahan posisi/nomor. G001-G502 tidak dibuat.

Lantai dibuat sebagai satu permukaan triangulasi dari poligon batas tapak yang sama. Zona warna dan pita lorong terpisah tidak lagi ditumpuk di atasnya. Marka memakai bidang tipis tanpa ketebalan trotoar; kerb kuning/gelap dihapus. Dinding ruangan dan fondasi objek tetap. Perubahan ini tidak menetapkan ukuran jalan fisik atau arah lalu lintas baru.

Bagian berikut merupakan catatan riwayat dasar data sampai revisi 6. Penyebutan warna lama menjelaskan riwayat, bukan tema aktif revisi 7. Tema aktif ada di WARNA_MESIN.md.

---

# Catatan pemetaan — revisi 7 DWG, 11 November 2026

Sumber utama: DENAH LUASAN PERUSAHAAN PT. SMM.dwg yang diberikan pengguna. DWG dikonversi secara lokal untuk membaca koordinat, label, dan jejak objek. File sumber tidak diubah; hash SHA-256 salinan kerja sama dengan sumber: FCB4D5069C48C3A753008C8E76771E01C38C24A80F4C2CBE7C77CBC7CF104359.

## Dasar model

230 objek terdiri dari 199 objek berlabel Jejak DWG dan 31 Interpretasi DWG. Jejak DWG berarti batas horizontal objek dicocokkan dengan geometri CAD, bukan bahwa bentuk tiga dimensinya sudah terukur. Interpretasi DWG berarti pembagian volume, batas, atau posisi sementara masih memerlukan konfirmasi. Detail objek dan CSV menampilkan dasar tersebut.

Label serta ID visual versi PDF dipertahankan bila masih sesuai; DWG memperbarui posisi dan kelompok yang berubah. 24 objek lama tidak lagi ditampilkan dan 26 objek baru ditambahkan. Rincian perubahan tersedia di cad_reference/perubahan-dwg.json. Fasilitas dan dinding yang belum dirinci ulang memakai representasi sederhana; tidak semua elemen adalah ekstrusi langsung DWG.

Batas tapak mengikuti poligon utama DWG. Koordinat CAD didaftarkan ke bidang tampilan model; tinggi, bentuk mesin, elevasi, tebal dinding, dan lebar lorong masih konseptual. ATAS DENAH bukan arah utara geografis. Atap terbuka agar mesin terlihat. Model ini bukan gambar fabrikasi atau dasar pengukuran jarak keselamatan. Detail komponen CAD yang sangat rapat disederhanakan pada gambar pembanding.

## Jetflow

87 jetflow dibaca dari label dan jejak DWG. Sesuai instruksi pengguna, badan dibuat memanjang sejajar lorong, dengan pintu, panel operator, dan platform di sisi yang menghadap lorong. Panah menunjukkan sisi depan. Dua baris di kiri dan kanan lorong menghadap ke dalam, bukan membelakangi jalan.

Kelompok A memiliki beberapa label 1A/2A/3A yang tidak mempunyai pasangan langsung di sisi seberang pada jejak DWG. Objek tersebut tetap di posisi sumber, dengan pintu menghadap akses terdekat; pasangan dan sisi jalan perlu diperiksa di lapangan. Lorong adalah bantuan visual yang ditentukan dari sela barisan, bukan data jalur transportasi terverifikasi.

## Area

| Area | Objek |
|---|---:|
| Finishing depan | 18 |
| Dyeing A | 6 |
| Dyeing B | 18 |
| Dyeing C | 17 |
| Dyeing D | 18 |
| Finishing tengah | 14 |
| Continuous & preparasi | 22 |
| Greige | 1 |
| Inspeksi | 18 |
| Finishing timur | 18 |
| Dyeing F | 16 |
| Kantor & depan | 12 |
| Dyeing E | 13 |
| Utilitas boiler | 11 |
| Gudang obat | 1 |
| Gudang & R&D | 5 |
| IPAL & halaman | 5 |
| Workshop & project | 2 |
| Tangki & dosing | 15 |
| Total | 230 |

Klasifikasi ringkasan: 189 mesin dan 41 fasilitas/utilitas. Jumlah area mencakup fasilitas di dalamnya; misalnya Dyeing E memuat 12 jetflow dan satu trafo. Pengelompokan ini untuk navigasi.

Area mini dyeing dan mesin bakar bulu dibuat sebagai volume sementara karena jumlah dan bentuk mesin belum ditetapkan. Rencana Dongnam baru mempertahankan keterangan RENCANA dari DWG dan bukan konfirmasi mesin sudah terpasang. ST-2 dan MIXER memakai kotak sementara mengikuti lokasi label.

## Label dan cakupan

Label berulang seperti CANLAR JF 1A dan CANLAR JF 12B dipertahankan; akhiran posisi dan ID unik membedakannya. Nomor tidak dikoreksi secara diam-diam. Nama umum dari inventaris versi sebelumnya tetap bersifat sementara jika DWG tidak memberikan identitas yang lebih jelas.

Area produksi, greige, kantor, gudang, boiler/utilitas, halaman dan IPAL yang dapat dipetakan di dalam batas sumber ditampilkan. Catatan sumber masih menyebut area di luar cakupan seperti parkir, satpam, AOC, jalan Tangkil, aerasi/kantor IPAL, cuci mobil/TPS5R, Amidis, TPA, bengkel otomotif, dan gudang belakang Amidis. Area di luar cakupan tersebut belum direkonstruksi sebagai fasilitas terverifikasi.

73 penanda jaringan PDF versi sebelumnya diarsipkan bersama versi 2. Penanda itu tidak dianggap berasal dari DWG dan tidak ditampilkan pada versi ini. Tidak ada topologi atau status jaringan produksi yang diasumsikan.

Penyempurnaan berikutnya memerlukan konfirmasi label berulang dan sisi akses kelompok A, foto/tipe mesin, ukuran lapangan, denah area di luar cakupan, serta daftar tag/sumber data untuk monitoring live.

## Koreksi Ehwa, kalender, dan LA dispensing

- A183 / Finishing Ehwa: jejak penuh DWG 3ABFE, menggantikan kotak pendek sebelumnya.
- A252 / Kalender depan 1 (NEW): jejak DWG 3ABFF, terletak di sebelah kiri Ehwa pada tampak atas sumber.
- A006 sampai A001: diberi nomor Kalender depan 2 sampai 7 dari kiri ke kanan. Posisi lama tetap; nama tampilan mengikuti koreksi pengguna, label sumber mempertahankan nomor lama.
- A253 dan A254: LA dispensing lantai 2 dan lantai 3, ditumpuk di atas bidang dosing. Pemisahan lantai berasal dari keterangan pengguna, bentuk rinci dan pembagian modul merupakan interpretasi gambar. Kedua objek mewakili tingkat dari area/peralatan yang sama, bukan dua unit mesin terverifikasi. Geometri atas disederhanakan dan tidak dimaksudkan sebagai gambar konstruksi struktur atau jalur pipa aktual.
- Tinggi antarlantai, model perangkat, dan jumlah tangki/hopper visual masih sementara. Satu tingkat bisa ditampilkan terpisah untuk peninjauan.

Gambar koreksi disalin ke cad_reference/revision4 dan disematkan dalam HTML. Source DWG dan gambar asli tidak diubah. Versi 3 sebelum koreksi disimpan di archive_v3_dwg.

## Koreksi nama dan warna revisi 5.2

79 objek diberi warna sesuai kelompok mesin pengguna. Pemetaan terpusat di machine-colors.js; daftar warna dan ID ada di WARNA_MESIN.md. Kelompok calator belakang berarti Calator tengah 1–7 sesuai konfirmasi pengguna. Kalender belakang adalah kelompok berbeda yang sebelumnya bernama Lafer depan.

- A137: Lafer depan 1 menjadi Kalender belakang 1.
- A138: Lafer depan 2 menjadi Kalender belakang 2.
- A139: Lafer depan 3 menjadi Kalender belakang 3.
- A140: Lafer depan 4 menjadi Kalender belakang 4.
- A134: Lafer depan 5 menjadi Kalender belakang 5.

Kelima mesin tetap dalam area navigasi Finishing depan agar posisi dan pengelompokan layout terjaga; kata belakang merupakan nama kelompok mesin. Label sumber disimpan untuk jejak referensi. Tidak ada perubahan koordinat atau bentuk. Metadata layout diperbarui ke revisi 5.2 untuk mencatat perubahan nama; geometri mengikuti revisi 4. Arsip sebelum koreksi terakhir ada di archive_v5_1_dwg.

## Revisi 6 — Greige, jalan, warna area

1.292 kode dari empat PDF bernomor ditambahkan sebagai lapisan lokasi Greige, terpisah dari 230 ID mesin/fasilitas. 1.284 lokasi dapat diisi data roll; 8 titik merah tidak menerima roll. Denah pallet lantai 1 kelima menjadi gambar referensi umum. PANDUAN_GREIGE.md menjelaskan sumber, selisih angka 242/241 pada denah atas, dan format CSV. File sumber PDF tidak diubah.

Koordinat 3D lokasi ditransformasikan secara proporsional ke zona Greige, bukan registrasi koordinat CAD survei. Tinggi bidang atas 4,8 unit visual sementara. Label kode pada denah tetap mengacu posisi teks sumber. Titik dapat dipilih dari instans pallet di 3D atau tombol pada gambar PDF.

Delapan rute akses/penghubung ditambahkan di celah model, serta delapan lorong jetflow yang sudah ada diberi permukaan biru dan marka. Dua label JALAN dari DWG membantu identifikasi akses di sisi timur/utilitas; jalur penghubung lain merupakan interpretasi visual. Batas dan lebar bukan hasil survei, arah lalu lintas, atau jalur evakuasi. Permukaan jalan dapat disembunyikan lewat Alur jalan. Warna zona, ruangan, batas tapak, dan model bawaan diperjelas; 79 warna khusus mesin tetap dari instruksi pengguna.

Data roll disimpan lokal di browser, tidak tertanam dalam paket rilis. Pengujian menggunakan ID QA-ROLL pada origin localhost terpisah; data tersebut tidak menjadi stok bawaan.
