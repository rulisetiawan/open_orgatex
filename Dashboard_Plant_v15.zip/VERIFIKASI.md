# Verifikasi revisi 15

12 November 2026. Pemeriksaan menggunakan Node/Three.js CPU, pemeriksaan peta tekstur, sumber, build, dan paket ZIP.

- Sembilan tekstur prosedural deterministik diperiksa dimensinya, ruang warna, mipmap, dan independensinya dari DOM/jaringan. Perubahan intensitas serat stainless lebih kuat melintang serat daripada memanjang; peta roughness/height tetap linear.
- Swatch tekstur asli ditinjau sebagai gambar lokal. Ini pemeriksaan peta datar, bukan render WebGL model pabrik.
- 7,995 bagian detail baru memiliki dimensi positif, koordinat/rotasi finite, serta geometri dan material valid. Detail berada dalam footprint lama dengan toleransi list tipis 0,06 satuan model.
- Generator pooling dan geometri aplikasi yang sebenarnya dijalankan dengan adapter scene CPU. Seluruh bagian mewarisi asset dan lantai, termasuk LA dispensing lantai 2/3. Terdapat 54 pool instanced, 12,039 bagian model, dan 718,008 segitiga pada model mesin/fasilitas yang diperiksa. Ini hitungan geometri, bukan hasil pengukuran FPS.
- Raycast pada 191 geometri layar HMI mempertahankan identitas mesin induk. Dua ray adegan penuh terhalang dinding lama A220 pada A233/A234; penghalang dihormati, bukan dilewati untuk memilih mesin. Tidak dilakukan perubahan posisi untuk menghilangkan kondisi lama ini.
- Layar HMI dekoratif tidak menampilkan angka proses; dial dekoratif tidak memiliki jarum. Tidak ditambahkan sumber data atau kendali mesin.
- Koordinat dan arah mesin, seluruh berkas Greige yang diperiksa, penyimpanan roll, glow status/area, lantai, dan pengaturan waktu sama dengan arsip R14.
- Uji regresi geometri glow R14, waktu 1.440 menit R13, layout/data Greige R12, dan status mesin R9 lulus. Greige tetap 502 ID, 499 posisi unik lantai 1, dan G076/G078/G080 menunggu koreksi posisi.
- Sintaks JavaScript, build mandiri, serta integritas ZIP diperiksa. Paket berisi 10 berkas; CRC, daftar isi, dan kesamaan HTML divalidasi. Hash dicatat di release-manifest.json.

Pemeriksaan visual/interaksi browser belum dilakukan karena akses browser sebelumnya ditolak pemeriksaan persetujuan otomatis terkait izin origin. Pemeriksaan tekstur datar dan geometri CPU tidak membuktikan hasil shader WebGL, frame rate, atau kecocokan visual persis dengan referensi. Tidak ada screenshot browser terbaru, validasi mesin fisik, maupun koneksi PLC.
