# Palet masterplan pastel — revisi 15

12 November 2026. Penyesuaian lantai, mesin, dan garis tepi terhadap referensi Isometric Factory Masterplan in Pastel Zones.png. Warna hasil render masih dipengaruhi pencahayaan.

| Zona | Lantai rata |
|---|---|
| Gudang obat | Mint #addec9 |
| Produksi timur | Biru muda #b2dbf3 |
| IPAL & halaman | Lavender #c9c0ea |
| Utilitas / boiler | Periwinkle #acaedc |
| Gudang / R&D | Sage #b9dcca |
| Produksi depan | Mint #b5dfc8 |
| Tangki & dosing | Krem #e8dec2 |
| Kantor / depan | Lavender muda #cec5e9 |
| Greige | Abu kebiruan #c3d0e0 |
| Lantai penghubung | Abu biru terang #dae4ed |

Warna memenuhi permukaan zona dengan tekstur opaque, tanpa noise. Deck atas Greige mengikuti abu kebiruan. Lantai, jalan, dan koordinat pembatas tetap sama; tidak ditambah trotoar.

| Komponen | Warna |
|---|---|
| Bodi mesin | Silver #dde5eb |
| Penutup / panel atap | Putih dingin #f4f8fb |
| Bejana | Silver #d0dce4 |
| Tutup bejana | Silver terang #edf5f8 |
| Chassis | Abu biru #92a4af |
| Panel operator | Slate #486574 |
| Aksen dekoratif | Cyan #75d4e3 |
| Layar | Cyan pucat #c3f4fa |
| Boiler | Slate #738995 / atap #415b69 |
| Pembatas fisik | Putih abu #e0e9ef |
| Sisi pelat dasar | Putih abu #e2ebf1 |

Material cat dibuat satin dan metal dibuat lebih reflektif. Kabinet memakai bevel tipis, panel atap disegmentasi sesuai panjang objek, dan cincin cyan bejana diperkecil. Semua memakai geometri instanced; dimensi utama dan orientasi jetflow tidak berubah.

Garis tepi menggunakan inti putih #f4feff, rim cyan #9beafa, dan halo cyan #71d8ed. Jalur luar lebih lebar daripada batas zona; sudut jalur tertutup tersambung. Ada enam mesh glow total. Slider mengatur ketiga lapisan sekaligus, tanpa mengubah warna lantai.

Cyan dekoratif tidak menandakan mesin menyala. Nyala, Stop, Maintenance, dan Downtime tetap memakai indikator status terpisah; objek tanpa data tidak mendapat status operasi buatan.

Latar siang putih lembut dan latar malam biru donker tetap mengikuti waktu Asia/Jakarta. Transisi pagi 05.30–07.00 dan sore 16.30–19.00 WIB; mode pratinjau siang/malam tetap tersedia.


## Tekstur dan list industrial

Revisi 15 menambahkan 9 peta tekstur prosedural 256 × 256: warna/roughness/height stainless, warna/height cat satin, pola antiselip, ventilasi, HMI, dan dial. Peta warna memakai sRGB; peta roughness/height memakai data linear. Detail serat metal bersifat arah dan halus, bukan noise berwarna. Tidak ada gambar mesin atau foto permukaan eksternal yang dimuat.

Bodi metal memakai pantulan lebih kuat daripada cat, dengan roughness dan bump sangat kecil untuk mempertahankan tampilan bersih. List aluminium dan flange memakai material metal lebih mengilap; sambungan/gasket memakai karet matte abu gelap. Cyan tetap berupa aksen tipis dan tidak menutupi seluruh bodi.

Layar HMI dan dial hanya dekorasi kosong. Tombol pada bodi tidak memiliki aksi kontrol. Indikator status operasi tetap terpisah dan tidak diubah oleh tekstur.
