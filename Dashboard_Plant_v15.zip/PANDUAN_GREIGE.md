# Gudang Greige - revisi 12

12 November 2026.

## Denah baru dan kode lama

Lantai 1 menggunakan 502 simbol pallet hijau dari PDF terbaru. Nomor G001–G502 adalah ID visual sementara, bukan nomor yang tercetak pada sumber. Urutan mengikuti baris PDF dari atas ke bawah, dan kiri ke kanan dalam satu baris. Terdapat 14 baris simbol; lorong dan celah mengikuti sumber.

Tiga pasangan pada PDF bertumpuk: G075/G076, G077/G078 dan G079/G080. Pengguna akan memberikan koreksi posisi G076, G078, G080. Model 3D hanya menempatkan 499 posisi unik. Daftar tetap memuat 502 ID, dengan status Menunggu koreksi pada tiga ID tersebut. Angka dalam legenda data adalah jumlah ID, bukan jumlah posisi fisik unik. Koordinat ketiga ID dalam CSV penempatan dikosongkan sampai diperbaiki.

Denah lama g1, g2 dan g3 tetap tersedia untuk membuka 1.043 kode penyimpanan lantai bawah dan 4 fasilitas. Gudang atas tetap berisi 241 kode penyimpanan dan 4 fasilitas. Total register lama: 1.284 penyimpanan dan 8 fasilitas. Posisi bawah yang lama tidak ditampilkan bersamaan dengan susunan PDF terbaru pada 3D.

## Memilih dan mengisi data roll

1. Klik Nomor lokasi & roll kain atau klik pallet 3D.
2. Pilih Lantai 1 terbaru untuk G001–G502. Untuk data lama, pilih lembar Kode lama atau Gudang atas.
3. Cari nomor, misalnya G001, 6A atau AA23, atau klik titik pada denah.
4. Klik Template CSV dan isi kolom lokasi, id_roll, jenis_kain, lot, berat_kg, panjang_m. Kolom lokasi dan id_roll wajib. ID roll harus unik dalam satu daftar. Berat/panjang boleh kosong atau nol.
5. Impor CSV, periksa jumlah, lalu Terapkan data. Impor mengganti daftar yang dipilih saja. Data daftar lain tidak diubah.
6. Ekspor data roll menghasilkan CSV daftar yang sedang dibuka. Ekspor kedua daftar secara terpisah untuk mencadangkan semua data.

G001–G502 menggunakan penyimpanan browser terpisah dari kode lama; data lama tidak disalin ke ID baru. Impor kode lama pada denah baru (atau sebaliknya) ditolak. Data kode lama yang sudah tersimpan akan tetap dimuat. Ketersediaan penyimpanan bergantung pada browser dan alamat file; ekspor CSV untuk cadangan.

## Keterangan warna

- Abu muda: data roll untuk daftar ini belum dimuat.
- Hijau lembut: 0 roll dalam daftar impor terakhir, bukan konfirmasi kosong secara fisik.
- Biru: terdapat roll dalam daftar impor.
- Amber: titik dipilih.
- Merah/arsir: fasilitas atau penanda sumber, bukan tempat stok.
- Garis putus pada G075/G077/G079: terdapat simbol lain yang bertumpuk pada PDF. Bagian 3 ID menunggu koreksi dan tombol Simbol bertumpuk membuka ID terkait.

Status data baru dan lama dihitung terpisah. Memuat salah satu daftar tidak mengubah daftar lain menjadi kosong. Lantai abu kebiruan menunjukkan zona Greige, bukan isi stok. Tombol Teks 3D menyembunyikan nomor pada model tanpa menghapus titik atau data.

Sumber: DENAH PALETE KAIN GREIGE TERBARU-LANTAI 1.pdf untuk lantai bawah; empat PDF bernomor sebelumnya tetap menjadi arsip kode. Registrasi memakai Continuous 1, Continuous 2 dan Lafer SPA. Ukuran sumber dan posisi terhadap peralatan nyata belum diverifikasi di lapangan. Tidak ada data roll bawaan/demo.
