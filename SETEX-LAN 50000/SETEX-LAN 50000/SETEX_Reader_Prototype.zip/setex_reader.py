"""SETEX Reader v0.2: experimental Controller TCP and explicit demo mode."""
import csv
import ipaddress
import math
from pathlib import Path
import queue
import socket
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from datetime import datetime
from setex_controller import read_live, build_read

BASE = Path(__file__).resolve().parent
OBJECTS = {"IW - Info Words": 1025, "Info Bits": 1026,
           "LW - Link Words": 1001, "L - Link Bits": 1002,
           "ACT - Ist Words": 1010, "SET - Soll Words": 1009,
           "MW - Memory Words": 1058, "M - Memory Bits": 1057}
SERVICES = {"SV_READ (1)": 1, "SV_READ_BLOCK (11)": 11,
            "SV_READ_LIST (128)": 128}


def validate_request(service, obj, start, count):
    if service not in (1, 11, 128) or obj not in OBJECTS.values():
        raise ValueError("Perintah/objek tidak diizinkan.")
    if not 0 <= start <= 65535 or not 1 <= count <= 80 or start + count > 65536:
        raise ValueError("Alamat 0..65535, jumlah 1..80, rentang tidak boleh melampaui 65535.")
    if service == 128 and obj not in (1001, 1002):
        raise ValueError("Commands.csv tidak mencantumkan SV_READ_LIST untuk objek ini.\n"
                         "Untuk IW pilih SV_READ atau SV_READ_BLOCK.")


def read_values(mode, service, obj, start, count, tick):
    validate_request(service, obj, start, count)
    if mode != "SIMULASI":
        raise RuntimeError("Pembacaan LIVE belum tersedia: header sesi, serialisasi request, "
                           "dan decoder respons TCP belum terverifikasi.\n"
                           "Gunakan Tes TCP untuk memeriksa koneksi saja.")
    # Angka buatan yang sengaja tidak diberi label sensor/satuan fisik.
    return [((start + i) * 17 + tick) % (2 if obj in (1002, 1026, 1057) else 65536)
            for i in range(count)]


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("SETEX Reader v0.2 - Controller TCP")
        self.root.geometry("900x670")
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.busy = False
        self.rows = []
        self.ip = tk.StringVar(value="172.16.120.113")
        self.port = tk.StringVar(value="50000")
        self.mode = tk.StringVar(value="LIVE Controller (eksperimental)")
        self.service = tk.StringVar(value="SV_READ (1)")
        self.obj = tk.StringVar(value="IW - Info Words")
        self.quantity = tk.StringVar(value="Satuan")
        self.start = tk.StringVar(value="1")
        self.count = tk.StringVar(value="5")
        self.schedule = tk.StringVar(value="Sekali")
        self.interval = tk.StringVar(value="2")
        self.status = tk.StringVar(value="LIVE eksperimental: mulai dengan SV_READ / IW / alamat 1 / Sekali. Belum diuji pada PLC fisik.")
        box = ttk.Frame(root, padding=16)
        box.pack(fill="both", expand=True)
        ttk.Label(box, text="SETEX • Pembaca variabel", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(box, text="v0.2 • Controller TCP • LIVE eksperimental; hasil hanya tampil jika balasan lolos pemeriksaan.").pack(anchor="w", pady=(3, 12))
        form = ttk.Frame(box)
        form.pack(fill="x")
        self.controls = []
        fields = [("IP mesin", self.ip, None), ("Port TCP", self.port, None),
                  ("Sumber data", self.mode, ["LIVE Controller (eksperimental)", "SIMULASI"]),
                  ("Perintah", self.service, list(SERVICES)),
                  ("Objek", self.obj, list(OBJECTS)),
                  ("Jumlah data", self.quantity, ["Satuan", "Lebih dari 1"]),
                  ("Alamat awal", self.start, None), ("Jumlah alamat", self.count, None),
                  ("Pembacaan", self.schedule, ["Sekali", "Cyclic"]),
                  ("Interval (detik, minimal 1)", self.interval, None)]
        for i, (label, var, choices) in enumerate(fields):
            col, row = (i % 2) * 2, i // 2
            ttk.Label(form, text=label).grid(row=row, column=col, sticky="w", padx=(0, 8), pady=5)
            widget = (ttk.Combobox(form, textvariable=var, values=choices, state="readonly", width=23)
                      if choices else ttk.Entry(form, textvariable=var, width=26))
            widget.grid(row=row, column=col + 1, sticky="ew", padx=(0, 20), pady=5)
            self.controls.append((widget, "readonly" if choices else "normal"))
        form.columnconfigure(1, weight=1)
        form.columnconfigure(3, weight=1)
        buttons = ttk.Frame(box)
        buttons.pack(fill="x", pady=12)
        self.run_button = ttk.Button(buttons, text="Mulai baca", command=self.run)
        self.run_button.pack(side="left")
        self.stop_button = ttk.Button(buttons, text="Stop", command=self.stop, state="disabled")
        self.stop_button.pack(side="left", padx=8)
        self.probe_button = ttk.Button(buttons, text="Tes TCP saja", command=self.probe)
        self.probe_button.pack(side="left")
        ttk.Button(buttons, text="Ekspor CSV", command=self.export).pack(side="right")
        ttk.Label(box, textvariable=self.status, wraplength=840, foreground="#9b4500").pack(anchor="w", pady=6)
        frame = ttk.Frame(box)
        frame.pack(fill="both", expand=True)
        self.table = ttk.Treeview(frame, columns=("time", "mode", "obj", "address", "raw", "hex"), show="headings")
        for name, label, width in [("time", "Waktu", 155), ("mode", "Sumber", 90),
                                  ("obj", "Objek", 160), ("address", "Alamat", 80),
                                  ("raw", "Nilai mentah", 100), ("hex", "Hex", 80)]:
            self.table.heading(name, text=label)
            self.table.column(name, width=width)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        ttk.Label(box, text="Nilai tampil mentah. Mapping sensor, skala, dan satuan perlu validasi per mesin.").pack(anchor="w", pady=(8, 0))
        root.protocol("WM_DELETE_WINDOW", self.close)
        root.after(100, self.drain)

    def target(self):
        host = str(ipaddress.ip_address(self.ip.get().strip()))
        port = int(self.port.get())
        if not 1 <= port <= 65535:
            raise ValueError("Port harus 1..65535.")
        return host, port

    def set_busy(self, value):
        self.busy = value
        for widget, state in self.controls:
            widget.configure(state="disabled" if value else state)
        self.run_button.configure(state="disabled" if value else "normal")
        self.probe_button.configure(state="disabled" if value else "normal")
        self.stop_button.configure(state="normal" if value else "disabled")

    def run(self):
        if self.busy:
            return
        try:
            host, port = self.target()
            mode, service, obj = self.mode.get(), SERVICES[self.service.get()], OBJECTS[self.obj.get()]
            start = int(self.start.get())
            count = 1 if self.quantity.get() == "Satuan" else int(self.count.get())
            cyclic = self.schedule.get() == "Cyclic"
            interval = float(self.interval.get()) if cyclic else 1.0
            if not math.isfinite(interval) or interval < 1:
                raise ValueError("Interval harus angka minimal 1 detik.")
            validate_request(service, obj, start, count)
            if mode != "SIMULASI":
                build_read(service, obj, start, 1 if service == 1 else count)
        except (ValueError, RuntimeError) as exc:
            messagebox.showerror("Belum dapat membaca", str(exc))
            return
        self.rows.clear()
        self.table.delete(*self.table.get_children())
        self.stop_event.clear()
        self.set_busy(True)
        self.status.set("SIMULASI: angka buatan." if mode == "SIMULASI" else f"LIVE: membaca {host}:{port} ...")

        def worker():
            tick = 0
            try:
                while not self.stop_event.is_set():
                    values = (read_values(mode, service, obj, start, count, tick)
                              if mode == "SIMULASI" else read_live(host, port, service, obj, start, count, self.stop_event))
                    self.events.put(("values", (datetime.now().astimezone().isoformat(timespec="seconds"),
                                               self_name, start, values, mode)))
                    tick += 1
                    if not cyclic or self.stop_event.wait(interval):
                        break
            except Exception as exc:
                self.events.put(("status", f"Baca berhenti: {exc}"))
            finally:
                self.events.put(("done", None))

        self_name = self.obj.get()
        threading.Thread(target=worker, daemon=True).start()

    def probe(self):
        if self.busy:
            return
        try:
            target = self.target()
        except ValueError as exc:
            messagebox.showerror("IP/port tidak valid", str(exc))
            return
        self.stop_event.clear()
        self.set_busy(True)
        self.status.set("Mencoba koneksi TCP (timeout 3 detik)...")

        def worker():
            try:
                with socket.create_connection(target, timeout=3):
                    result = "TCP tersambung. Ini belum membuktikan protokol SETEX atau izin baca PLC."
            except OSError as exc:
                result = f"TCP gagal: {exc}"
            self.events.put(("status", result))
            self.events.put(("done", None))
        threading.Thread(target=worker, daemon=True).start()

    def stop(self):
        self.stop_event.set()
        self.status.set("Menghentikan proses; tes TCP menunggu timeout maksimal 3 detik.")

    def drain(self):
        try:
            while True:
                kind, data = self.events.get_nowait()
                if kind == "values":
                    stamp, obj, start, values, mode = data
                    for i, value in enumerate(values):
                        row = (stamp, mode, obj, start + i, value, f"0x{value:04X}")
                        self.rows.append(row)
                        self.table.insert("", "end", values=row)
                    # Batas memori untuk sesi cyclic panjang; ekspor hanya 5000 baris terakhir.
                    self.rows[:] = self.rows[-5000:]
                    children = self.table.get_children()
                    if len(children) > 5000:
                        self.table.delete(*children[:-5000])
                    self.table.yview_moveto(1)
                    self.status.set(f"{mode} • {stamp} • {len(values)} nilai mentah • maksimal 5000 baris.")
                elif kind == "status":
                    self.status.set(data)
                elif kind == "done":
                    self.set_busy(False)
        except queue.Empty:
            pass
        self.root.after(100, self.drain)

    def export(self):
        if not self.rows:
            messagebox.showinfo("CSV", "Belum ada data.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="SETEX_DATA.csv",
                                          filetypes=[("CSV", "*.csv")])
        if path:
            try:
                with open(path, "w", newline="", encoding="utf-8-sig") as handle:
                    writer = csv.writer(handle)
                    writer.writerow(["waktu", "sumber", "objek", "alamat", "raw", "hex"])
                    writer.writerows(self.rows)
                self.status.set(f"CSV disimpan: {path}")
            except OSError as exc:
                messagebox.showerror("Gagal menyimpan", str(exc))

    def close(self):
        self.stop_event.set()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
