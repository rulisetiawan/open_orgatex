"""Experimental function-level intervention, reconstructed from 13E HMI APIs.

Only Temperature Control 141; no generic parameter-41 guesses. No network on import.
"""
import math
import struct
from dataclasses import dataclass
from setex_controller import build_read, validate_response, _exchange, ProtocolError

FUNCTION_ID = 141
PARAMETERS = {
    'P1 - Suhu (°C)': (0, 0.0, 150.0),
    'P2 - Gradien (°C/min)': (1, 0.0, 9.9),
    'P3 - Waktu (min)': (2, 0.0, 180.0),
}


@dataclass(frozen=True)
class FunctionSnapshot:
    line: int
    function_id: int
    values: tuple


def function_frame(service, line=0, values=None):
    if service not in (1, 106) or type(line) is not int or not 0 <= line <= 6:
        raise ValueError('Service fungsi atau baris fungsi tidak valid.')
    if service == 106 and (values is None or len(values) != 6 or
                           any(not math.isfinite(v) for v in values)):
        raise ValueError('Perubahan fungsi membutuhkan enam nilai finite dari pembacaan sebelumnya.')
    frame = bytearray(build_read(1, 1025, 1))
    frame[20:] = bytes(len(frame) - 20)
    frame[15] = service
    struct.pack_into('<HH', frame, 16, 6, 64)
    struct.pack_into('<H', frame, 2, 80)
    frame[20] = line
    struct.pack_into('<H', frame, 21, FUNCTION_ID)
    if service == 106:
        for i, value in enumerate(values):
            struct.pack_into('<f', frame, 25 + 8 * i, value)
    # Matches Api_Rem_ReadFunction / Api_ChangeFunction builder; fields not
    # provided by those HMI calls remain zero (not copied from opaque response).
    return bytes(frame)


def decode_function(frame):
    size = validate_response(frame, 1, 6)
    if size != 64:
        raise ProtocolError(f'Layout fungsi tidak cocok: payload {size}, diharapkan 64. Lihat log.')
    line = frame[20]
    fid = struct.unpack_from('<H', frame, 21)[0]
    values = tuple(struct.unpack_from('<f', frame, 25 + 8*i)[0] for i in range(6))
    if fid != FUNCTION_ID or not 0 <= line <= 6 or any(not math.isfinite(v) for v in values):
        raise ProtocolError('Respons bukan Temperature Control 141 / konteks atau nilai tidak valid.')
    for index, minimum, maximum in PARAMETERS.values():
        if not minimum <= values[index] <= maximum + 0.00001:
            raise ProtocolError('Nilai fungsi di luar batas konfigurasi 13E; perubahan diblokir.')
    return FunctionSnapshot(line, fid, values)


def read_temperature(host, port, stop):
    return decode_function(_exchange(host, port, function_frame(1), stop))


def changed_values(snapshot, parameter, new_value):
    if snapshot.function_id != FUNCTION_ID or len(snapshot.values) != 6:
        raise ValueError('Snapshot fungsi tidak valid.')
    if parameter not in PARAMETERS:
        raise ValueError('Parameter tidak dikenali.')
    index, minimum, maximum = PARAMETERS[parameter]
    if not math.isfinite(new_value) or not minimum <= new_value <= maximum:
        raise ValueError(f'Nilai harus {minimum:g}..{maximum:g} dalam satuan tampilan.')
    values = list(snapshot.values)
    values[index] = new_value
    return tuple(values)


def change_temperature_once(host, port, snapshot, parameter, value, stop):
    values = changed_values(snapshot, parameter, value)
    request = function_frame(106, snapshot.line, values)
    current = read_temperature(host, port, stop)
    if current != snapshot:
        raise ProtocolError('Parameter/konteks fungsi berubah sejak konfirmasi. Baca dan konfirmasi ulang.')
    if stop.is_set():
        raise InterruptedError('Perubahan dibatalkan sebelum pengiriman.')
    result = dict(acknowledged=False, ack_error=None, readback=None, readback_error=None)
    try:
        response = _exchange(host, port, request, stop)
        validate_response(response, 106, 6)
        result['acknowledged'] = True
    except (OSError, RuntimeError) as exc:
        result['ack_error'] = str(exc)
    if stop.is_set():
        result['readback_error'] = 'Dihentikan; perintah yang sudah dikirim tidak dapat ditarik kembali.'
        return result
    try:
        result['readback'] = read_temperature(host, port, stop)
    except (OSError, RuntimeError) as exc:
        result['readback_error'] = str(exc)
    return result
