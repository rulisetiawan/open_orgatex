# SETEX Reader v0.3 — Controller TCP eksperimental

Tutup jendela versi lama, lalu klik JALANKAN_CONTROLLER_V03.bat atau JALANKAN.bat.
Judul yang benar: SETEX Reader v0.3 - IW / ACT / SET / LW / MW.
Python 3.10+ dengan tkinter; tidak membutuhkan paket pip untuk aplikasi.

Default sudah diatur: IP 172.16.120.113, port 50000, LIVE Controller
(eksperimental), SV_READ, IW - Info Words, Satuan, alamat 1, Sekali.
Klik Mulai baca. Tidak ada koneksi otomatis ketika aplikasi dibuka.

Ini implementasi LIVE eksperimental hasil penelusuran statis DLL 6A,
BELUM diuji pada kontroler fisik dan belum dipastikan cocok firmware target.
Mode LIVE benar-benar membuka soket dan mengirim permintaan baca. Tidak ada
penggantian dengan angka simulasi jika koneksi atau decoder gagal.
Nilai simulasi hanya muncul jika sumber SIMULASI dipilih secara eksplisit.

## Fitur
- SV_READ: satu alamat per transaksi; beberapa alamat dibaca satu per satu,
  dengan jeda 1 detik antartransaksi dan koneksi baru untuk setiap transaksi.
- SV_READ_BLOCK: satu permintaan berisi alamat awal dan jumlah (maksimal 80).
- Sekali atau Cyclic; interval minimal 1 detik setelah satu siklus selesai.
- Stop, tes TCP tanpa payload, ekspor CSV (5000 baris terakhir).
- Error/timeout menghentikan sesi, tanpa retry atau fallback protokol otomatis.
- LIVE mendukung word IW/LW/ACT/SET/MW. Decoder bit dan SV_READ_LIST LIVE
  belum diimplementasikan; pemilihan tersebut ditolak sebelum koneksi.

## Uji awal
1. Gunakan SV_READ / IW / alamat 1 / Satuan / Sekali dahulu.
2. Bandingkan dengan IW 1 di HMI pada waktu yang sama. Angka 2299 di foto
   sebelumnya adalah snapshot, bukan nilai yang harus selalu keluar.
3. Bila gagal, baca pesan status. controller_packets.jsonl menyimpan waktu,
   IP/port, frame TX dan RX termasuk respons parsial/timeout. Log bertambah
   selama pemakaian; arsipkan saat aplikasi berhenti bila ukurannya membesar.
4. Jangan menganggap lolos parser sebagai validasi mapping sensor. Cocokkan
   hasil beberapa alamat dengan HMI sebelum memakai cyclic.

Tabel menampilkan uint16 mentah dan hex. Belum ada konversi sensor, skala,
satuan engineering, maupun signed integer otomatis.

## Dasar implementasi dan batasnya
- RCClient.ini: Controller_Port=50000, RCServer_Port=50010.
- Commands.csv 6A: SV_READ + IW (1025), SV_READ_BLOCK + IW; bukan
  SV_READ_LIST + IW seperti dalam dokumen HTML sebelumnya.
- Api_ReadPLCWord dan Api_ReadPLCWords dalam SecomCE_D_BackGround_2d.dll
  membentuk payload alamat uint16 dan alamat+jumlah uint16.
- Jalur SecomCE_TCP_2d.dll menyalin header SC737, mengirim frame 516 byte,
  dan memakai field panjang data pada offset 18 serta data mulai offset 20.
- Decoder eksperimental mengharapkan jenis respons 2, service/objek yang
  sama, dan payload word persis sesuai jumlah. Layout lain ditolak dan dicatat.
- Field routing/header mengikuti penelusuran DLL; kebutuhan sesi, hak akses,
  atau perbedaan firmware pada mesin target masih perlu pembuktian.
- Implementasi tidak mengirim remote keyboard/mouse atau perintah tulis.
  Dampak beban dan batas koneksi tetap perlu diuji di mesin.

Validasi lokal: python -m unittest -v. Sebelas pengujian lulus, termasuk
respons terfragmentasi dan penolakan balasan salah. Respons uji dibuat lokal;
pengujian ini bukan bukti kompatibilitas perangkat.

## Pilihan objek v0.3

| Menu | ID | Arti |
| --- | --- | --- |
| IW | 1025 | Info Words |
| ACT / IST | 1010 | Nilai aktual |
| SET / SOLL | 1009 | Nilai target / setpoint |
| LW | 1001 | Link Words |
| MW | 1058 | Memory Words |

Pilih objek lalu isi alamat sesuai tabel objek tersebut pada mesin.
Contoh ACT alamat 1 tidak berarti sensor yang sama dengan IW alamat 1.
SET adalah nama kelompok data target, bukan instruksi menulis.
Semua objek word memakai SV_READ untuk satuan atau SV_READ_BLOCK untuk blok,
dan dapat dibaca sekali atau cyclic. Dukungan dasar kelima objek sudah ada
pada v0.2; v0.3 memperjelas menu dan menambah pengujian lintas objek.

LIVE hanya menampilkan objek word dan perintah yang diimplementasikan.
Mengganti sumber/objek mengosongkan tabel sebelumnya supaya hasil lama
bukan dianggap sebagai hasil objek baru. Tiap hasil tetap mencatat objeknya.
Belum dilakukan pengujian fisik ACT/SET/LW/MW dari lingkungan pengembang.
