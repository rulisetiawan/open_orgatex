"""Experimental SC737 TCP reader reconstructed from 6A x86 DLLs.

No remote screen/keyboard services. Hardware compatibility remains unverified.
"""
import json
import socket
import struct
import threading
import time
from datetime import datetime
from pathlib import Path

FRAME_SIZE = 516
LOG_PATH = Path(__file__).resolve().parent / 'controller_packets.jsonl'
LOG_LOCK = threading.Lock()
ALLOWED_OBJECTS = {1001, 1002, 1009, 1010, 1025, 1026, 1057, 1058}


class ProtocolError(RuntimeError):
    pass


def build_read(service, obj, address, count=1):
    if service not in (1, 11) or obj not in ALLOWED_OBJECTS:
        raise ValueError('LIVE hanya mendukung SV_READ dan SV_READ_BLOCK pada objek PLC terpilih.')
    if obj in (1002, 1026, 1057):
        raise ValueError('Decoder bit LIVE belum terverifikasi. Pilih objek word dahulu.')
    if not 0 <= address <= 65535 or not 1 <= count <= 80 or address + count > 65536:
        raise ValueError('Rentang alamat tidak valid.')
    if service == 1 and count != 1:
        raise ValueError('SV_READ mengirim satu alamat per transaksi.')
    payload = struct.pack('<H', address) if service == 1 else struct.pack('<HH', address, count)
    frame = bytearray(FRAME_SIZE)
    struct.pack_into('<HH', frame, 0, 2, 16 + len(payload))
    # Server rewrites routing bytes 4,5 and socket ticket at 7.
    # Api_* sets word +9 to 1, message type +14 to 1, service +15,
    # object +16, data length +18, data +20.
    frame[4:7] = bytes((10, 12, 0))
    struct.pack_into('<H', frame, 9, 1)
    frame[14] = 1
    frame[15] = service
    struct.pack_into('<HH', frame, 16, obj, len(payload))
    frame[20:20 + len(payload)] = payload
    return bytes(frame)


def parse_response(frame, service, obj, count):
    if len(frame) != FRAME_SIZE:
        raise ProtocolError(f'Frame harus {FRAME_SIZE} byte; diterima {len(frame)}.')
    magic, declared = struct.unpack_from('<HH', frame)
    reply_obj, size = struct.unpack_from('<HH', frame, 16)
    if magic != 2 or size > 486 or declared != size + 16:
        raise ProtocolError('Magic/panjang balasan tidak cocok dengan format hasil penelusuran DLL.')
    if frame[15] != service or reply_obj != obj:
        raise ProtocolError(f'Balasan bukan perintah/objek yang diminta: service={frame[15]}, object={reply_obj}.')
    if frame[14] != 2:
        raise ProtocolError(f'Controller tidak mengirim respons data (jenis={frame[14]}, '
                            f'payload={frame[20:20+size].hex(" ")}). Lihat log paket.')
    if size != count * 2:
        raise ProtocolError(f'Payload {size} byte, diharapkan {count * 2}. '
                            'Nilai tidak ditampilkan karena layout balasan belum cocok.')
    return list(struct.unpack_from('<' + 'H' * count, frame, 20))


def trace(direction, host, port, data):
    row = dict(time=datetime.now().astimezone().isoformat(), direction=direction,
               host=host, port=port, bytes=len(data), hex=data.hex(' '))
    with LOG_LOCK, LOG_PATH.open('a', encoding='utf-8') as handle:
        handle.write(json.dumps(row) + '\n')


def transact(host, port, service, obj, address, count, stop, timeout=3):
    request = build_read(service, obj, address, count)
    if stop.is_set():
        raise InterruptedError('Dihentikan.')
    with socket.create_connection((host, port), timeout=timeout) as sock:
        sock.settimeout(0.2)
        trace('TX', host, port, request)
        sock.sendall(request)
        received = bytearray()
        deadline = time.monotonic() + timeout
        try:
            while len(received) < FRAME_SIZE:
                if stop.is_set():
                    raise InterruptedError('Dihentikan.')
                if time.monotonic() >= deadline:
                    raise TimeoutError(f'Timeout balasan: {len(received)}/{FRAME_SIZE} byte. Lihat log paket.')
                try:
                    chunk = sock.recv(FRAME_SIZE - len(received))
                except socket.timeout:
                    continue
                if not chunk:
                    raise ProtocolError(f'Controller menutup koneksi setelah {len(received)} byte.')
                received.extend(chunk)
        finally:
            trace('RX', host, port, bytes(received))
    return parse_response(bytes(received), service, obj, count)


def read_live(host, port, service, obj, address, count, stop):
    # Single reads are paced; no automatic retries or protocol fallback.
    if service == 1:
        values = []
        for offset in range(count):
            if offset and stop.wait(1):
                raise InterruptedError('Dihentikan.')
            values.extend(transact(host, port, 1, obj, address + offset, 1, stop))
        return values
    return transact(host, port, service, obj, address, count, stop)
