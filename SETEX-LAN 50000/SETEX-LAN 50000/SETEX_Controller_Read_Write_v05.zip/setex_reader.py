"""SETEX Controller v0.5: read and explicitly confirmed single-word write."""
import csv
import ipaddress
import math
from pathlib import Path
import queue
import socket
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk
from datetime import datetime
from setex_controller import read_live, build_read, build_write, write_once_verified

BASE = Path(__file__).resolve().parent
OBJECTS = {"IW - Info Words": 1025, "Info Bits": 1026,
           "LW - Link Words": 1001, "L - Link Bits": 1002,
           "ACT - Aktual (IST)": 1010, "SET - Target (SOLL)": 1009,
           "MW - Memory Words": 1058, "M - Memory Bits": 1057}
SERVICES = {"SV_READ (1)": 1, "SV_READ_BLOCK (11)": 11,
            "SV_READ_LIST (128)": 128}
WORD_OBJECTS = {name: code for name, code in OBJECTS.items()
                if code not in (1002, 1026, 1057)}
OBJECT_HELP = {
    1025: "IW: Info Words. Nomor alamat mengikuti tabel IW mesin.",
    1010: "ACT / IST: nilai aktual. Alamat ACT terpisah dari alamat IW.",
    1009: "SET / SOLL: nilai target/setpoint. Mulai baca hanya membaca; write memakai tombol terpisah.",
    1001: "LW: Link Words. Alamat LW terpisah dari IW, ACT, dan SET.",
    1058: "MW: Memory Words. Nilai mentah 16 bit; arti alamat mengikuti PLC mesin.",
}


def parse_addresses(text, quantity, count_text):
    parts = text.split(',')
    if any(not part.strip() for part in parts):
        raise ValueError('Daftar alamat tidak boleh kosong. Contoh: 10,20,30,40')
    if len(parts) > 1:
        addresses = [int(part.strip()) for part in parts]
    else:
        start = int(text.strip())
        count = 1 if quantity == 'Satuan' else int(count_text)
        if not 1 <= count <= 80:
            raise ValueError('Jumlah alamat harus 1..80.')
        addresses = list(range(start, start + count))
    if not 1 <= len(addresses) <= 80 or any(not 0 <= a <= 65535 for a in addresses):
        raise ValueError('Maksimal 80 alamat, masing-masing 0..65535.')
    if len(set(addresses)) != len(addresses):
        raise ValueError('Alamat duplikat dalam daftar. Tulis setiap alamat satu kali.')
    return addresses


def validate_request(service, obj, start, count):
    if service not in (1, 11, 128) or obj not in OBJECTS.values():
        raise ValueError("Perintah/objek tidak diizinkan.")
    if not 0 <= start <= 65535 or not 1 <= count <= 80 or start + count > 65536:
        raise ValueError("Alamat 0..65535, jumlah 1..80, rentang tidak boleh melampaui 65535.")
    if service == 128 and obj not in (1001, 1002):
        raise ValueError("Commands.csv tidak mencantumkan SV_READ_LIST untuk objek ini.\n"
                         "Untuk IW pilih SV_READ atau SV_READ_BLOCK.")


def read_values(mode, service, obj, start, count, tick):
    validate_request(service, obj, start, count)
    if mode != "SIMULASI":
        raise RuntimeError("Pembacaan LIVE belum tersedia: header sesi, serialisasi request, "
                           "dan decoder respons TCP belum terverifikasi.\n"
                           "Gunakan Tes TCP untuk memeriksa koneksi saja.")
    # Angka buatan yang sengaja tidak diberi label sensor/satuan fisik.
    return [((start + i) * 17 + tick) % (2 if obj in (1002, 1026, 1057) else 65536)
            for i in range(count)]


class App:
    def __init__(self, root):
        self.root = root
        self.root.title("SETEX Controller v0.5 - Read / Write")
        self.root.geometry("960x780")
        self.events = queue.Queue()
        self.stop_event = threading.Event()
        self.busy = False
        self.rows = []
        self.ip = tk.StringVar(value="172.16.120.113")
        self.port = tk.StringVar(value="50000")
        self.mode = tk.StringVar(value="LIVE Controller (eksperimental)")
        self.service = tk.StringVar(value="SV_READ (1)")
        self.obj = tk.StringVar(value="IW - Info Words")
        self.quantity = tk.StringVar(value="Satuan")
        self.start = tk.StringVar(value="1")
        self.count = tk.StringVar(value="5")
        self.schedule = tk.StringVar(value="Sekali")
        self.interval = tk.StringVar(value="2")
        self.write_value = tk.StringVar()
        self.status = tk.StringVar(value="LIVE eksperimental: mulai dengan SV_READ / IW / alamat 1 / Sekali. Belum diuji pada PLC fisik.")
        box = ttk.Frame(root, padding=16)
        box.pack(fill="both", expand=True)
        ttk.Label(box, text="SETEX • Controller Read / Write", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(box, text="v0.5 • Write satu word dengan konfirmasi dan baca ulang • Controller TCP eksperimental.").pack(anchor="w", pady=(3, 12))
        form = ttk.Frame(box)
        form.pack(fill="x")
        self.controls = []
        fields = [("IP mesin", self.ip, None), ("Port TCP", self.port, None),
                  ("Sumber data", self.mode, ["LIVE Controller (eksperimental)", "SIMULASI"]),
                  ("Perintah", self.service, list(SERVICES)),
                  ("Objek", self.obj, list(OBJECTS)),
                  ("Jumlah data", self.quantity, ["Satuan", "Lebih dari 1"]),
                  ("Alamat awal / daftar", self.start, None), ("Jumlah (untuk rentang)", self.count, None),
                  ("Pembacaan", self.schedule, ["Sekali", "Cyclic"]),
                  ("Interval (detik, minimal 1)", self.interval, None)]
        for i, (label, var, choices) in enumerate(fields):
            col, row = (i % 2) * 2, i // 2
            ttk.Label(form, text=label).grid(row=row, column=col, sticky="w", padx=(0, 8), pady=5)
            widget = (ttk.Combobox(form, textvariable=var, values=choices, state="readonly", width=23)
                      if choices else ttk.Entry(form, textvariable=var, width=26))
            widget.grid(row=row, column=col + 1, sticky="ew", padx=(0, 20), pady=5)
            self.controls.append((widget, "readonly" if choices else "normal"))
            if var is self.obj:
                self.object_combo = widget
            if var is self.service:
                self.service_combo = widget
        form.columnconfigure(1, weight=1)
        form.columnconfigure(3, weight=1)
        self.object_hint = tk.StringVar()
        ttk.Label(box, textvariable=self.object_hint, wraplength=840).pack(anchor="w", pady=(8, 0))
        buttons = ttk.Frame(box)
        buttons.pack(fill="x", pady=12)
        self.run_button = ttk.Button(buttons, text="Mulai baca", command=self.run)
        self.run_button.pack(side="left")
        self.stop_button = ttk.Button(buttons, text="Stop", command=self.stop, state="disabled")
        self.stop_button.pack(side="left", padx=8)
        self.probe_button = ttk.Button(buttons, text="Tes TCP saja", command=self.probe)
        self.probe_button.pack(side="left")
        ttk.Button(buttons, text="Ekspor CSV", command=self.export).pack(side="right")
        write_box = ttk.LabelFrame(box, text="SV_WRITE (2) — satu alamat, satu kali", padding=8)
        write_box.pack(fill="x", pady=(0, 6))
        ttk.Label(write_box, text="Nilai mentah baru (0..65535)").pack(side="left")
        write_entry = ttk.Entry(write_box, textvariable=self.write_value, width=12)
        write_entry.pack(side="left", padx=8)
        self.controls.append((write_entry, 'normal'))
        self.write_button = ttk.Button(write_box, text="Baca nilai lama → Konfirmasi write", command=self.prepare_write)
        self.write_button.pack(side="left")
        ttk.Label(box, textvariable=self.status, wraplength=840, foreground="#9b4500").pack(anchor="w", pady=6)
        frame = ttk.Frame(box)
        frame.pack(fill="both", expand=True)
        self.table = ttk.Treeview(frame, columns=("time", "mode", "obj", "address", "raw", "hex"), show="headings")
        for name, label, width in [("time", "Waktu", 155), ("mode", "Sumber", 90),
                                  ("obj", "Objek", 160), ("address", "Alamat", 80),
                                  ("raw", "Nilai mentah", 100), ("hex", "Hex", 80)]:
            self.table.heading(name, text=label)
            self.table.column(name, width=width)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=self.table.yview)
        self.table.configure(yscrollcommand=scroll.set)
        self.table.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        ttk.Label(box, text="Nilai tampil mentah. Mapping sensor, skala, dan satuan perlu validasi per mesin.").pack(anchor="w", pady=(8, 0))
        root.protocol("WM_DELETE_WINDOW", self.close)
        self.mode.trace_add("write", self.update_choices)
        self.obj.trace_add("write", self.update_object_hint)
        self.update_choices()
        root.after(100, self.drain)

    def update_choices(self, *_):
        live = self.mode.get() != "SIMULASI"
        choices = WORD_OBJECTS if live else OBJECTS
        services = list(SERVICES)[:2] if live else list(SERVICES)
        self.object_combo.configure(values=list(choices))
        self.service_combo.configure(values=services)
        if self.obj.get() not in choices:
            self.obj.set("IW - Info Words")
        if self.service.get() not in services:
            self.service.set("SV_READ (1)")
        self.update_object_hint()

    def update_object_hint(self, *_):
        obj = OBJECTS[self.obj.get()]
        self.object_hint.set(f"Object ID {obj} / 0x{obj:04X} • " +
                             OBJECT_HELP.get(obj, "Objek bit: simulasi saja."))
        if not self.busy:
            self.rows.clear()
            self.table.delete(*self.table.get_children())

    def target(self):
        host = str(ipaddress.ip_address(self.ip.get().strip()))
        port = int(self.port.get())
        if not 1 <= port <= 65535:
            raise ValueError("Port harus 1..65535.")
        return host, port

    def set_busy(self, value):
        self.busy = value
        for widget, state in self.controls:
            widget.configure(state="disabled" if value else state)
        self.run_button.configure(state="disabled" if value else "normal")
        self.probe_button.configure(state="disabled" if value else "normal")
        self.write_button.configure(state="disabled" if value else "normal")
        self.stop_button.configure(state="normal" if value else "disabled")

    def prepare_write(self):
        if self.busy:
            return
        try:
            if self.mode.get() == 'SIMULASI':
                raise ValueError('Write hanya tersedia dalam mode LIVE Controller.')
            if self.schedule.get() != 'Sekali':
                raise ValueError('Pilih Sekali untuk write. Cyclic hanya untuk baca.')
            host, port = self.target()
            addresses = parse_addresses(self.start.get(), self.quantity.get(), self.count.get())
            if len(addresses) != 1:
                raise ValueError('Write versi ini hanya satu alamat. Hapus daftar/rentang dan pilih Satuan.')
            value = int(self.write_value.get().strip(), 10)
            obj_name = self.obj.get()
            obj, address = OBJECTS[obj_name], addresses[0]
            build_write(obj, address, value)
        except (ValueError, RuntimeError) as exc:
            messagebox.showerror('Write belum dapat diproses', str(exc))
            return
        self.stop_event.clear()
        self.set_busy(True)
        self.status.set(f'Membaca nilai lama {obj_name} alamat {address}; belum mengirim write ...')
        # Snapshot target retained through confirmation, unaffected by later edits.
        target = (host, port, obj_name, obj, address, value)

        def worker():
            try:
                old = read_live(host, port, 1, obj, address, 1, self.stop_event)[0]
                self.events.put(('confirm_write', (target, old)))
            except Exception as exc:
                self.events.put(('status', f'Persiapan gagal; write belum dikirim: {exc}'))
                self.events.put(('done', None))
        threading.Thread(target=worker, daemon=True).start()

    def confirm_write(self, target, old):
        if self.stop_event.is_set():
            self.status.set('Write dibatalkan sebelum pengiriman.')
            self.set_busy(False)
            return
        host, port, obj_name, obj, address, value = target
        confirmed = messagebox.askyesno('Konfirmasi SV_WRITE — PLC asli',
            f'Tujuan: {host}:{port}\nObjek: {obj_name} (ID {obj})\nAlamat: {address}\n\n'
            f'Nilai lama: {old} (0x{old:04X})\nNilai baru: {value} (0x{value:04X})\n\n'
            'Kirim satu perintah write ke alamat ini?\nNilai adalah uint16 mentah, tanpa konversi satuan.',
            default='no')
        if not confirmed:
            self.status.set('Write dibatalkan; tidak ada perintah write dikirim.')
            self.set_busy(False)
            return
        self.status.set('Memeriksa ulang nilai lama, mengirim write sekali, lalu membaca kembali ...')

        def worker():
            try:
                result = write_once_verified(host, port, obj, address, value, old, self.stop_event)
                self.events.put(('write_result', (target, result)))
            except Exception as exc:
                self.events.put(('status', f'Write dibatalkan sebelum pengiriman: {exc}'))
            finally:
                self.events.put(('done', None))
        threading.Thread(target=worker, daemon=True).start()

    def run(self):
        if self.busy:
            return
        try:
            host, port = self.target()
            mode, service, obj = self.mode.get(), SERVICES[self.service.get()], OBJECTS[self.obj.get()]
            addresses = parse_addresses(self.start.get(), self.quantity.get(), self.count.get())
            start, count = addresses[0], len(addresses)
            contiguous = addresses == list(range(start, start + count))
            if service != 1 and not contiguous:
                raise ValueError('Daftar alamat terpisah memakai SV_READ (1). Pilih perintah tersebut.')
            cyclic = self.schedule.get() == "Cyclic"
            interval = float(self.interval.get()) if cyclic else 1.0
            if not math.isfinite(interval) or interval < 1:
                raise ValueError("Interval harus angka minimal 1 detik.")
            for address in addresses:
                validate_request(service, obj, address, 1)
            if mode != "SIMULASI":
                build_read(service, obj, start, 1 if service == 1 else count)
        except (ValueError, RuntimeError) as exc:
            messagebox.showerror("Belum dapat membaca", str(exc))
            return
        self.rows.clear()
        self.table.delete(*self.table.get_children())
        self.stop_event.clear()
        self.set_busy(True)
        self.status.set("SIMULASI: angka buatan." if mode == "SIMULASI" else f"LIVE: membaca {host}:{port} ...")

        def worker():
            tick = 0
            try:
                while not self.stop_event.is_set():
                    if service == 1:
                        values = []
                        for index, address in enumerate(addresses):
                            if self.stop_event.is_set() or (index and self.stop_event.wait(1)):
                                raise InterruptedError('Dihentikan.')
                            values.extend(read_values(mode, service, obj, address, 1, tick)
                                          if mode == 'SIMULASI' else
                                          read_live(host, port, service, obj, address, 1, self.stop_event))
                    else:
                        values = (read_values(mode, service, obj, start, count, tick)
                                  if mode == "SIMULASI" else read_live(host, port, service, obj, start, count, self.stop_event))
                    self.events.put(("values", (datetime.now().astimezone().isoformat(timespec="seconds"),
                                               self_name, addresses, values, mode)))
                    tick += 1
                    if not cyclic or self.stop_event.wait(interval):
                        break
            except Exception as exc:
                self.events.put(("status", f"Baca berhenti: {exc}"))
            finally:
                self.events.put(("done", None))

        self_name = self.obj.get()
        threading.Thread(target=worker, daemon=True).start()

    def probe(self):
        if self.busy:
            return
        try:
            target = self.target()
        except ValueError as exc:
            messagebox.showerror("IP/port tidak valid", str(exc))
            return
        self.stop_event.clear()
        self.set_busy(True)
        self.status.set("Mencoba koneksi TCP (timeout 3 detik)...")

        def worker():
            try:
                with socket.create_connection(target, timeout=3):
                    result = "TCP tersambung. Ini belum membuktikan protokol SETEX atau izin baca PLC."
            except OSError as exc:
                result = f"TCP gagal: {exc}"
            self.events.put(("status", result))
            self.events.put(("done", None))
        threading.Thread(target=worker, daemon=True).start()

    def stop(self):
        self.stop_event.set()
        self.status.set("Menghentikan proses; tes TCP menunggu timeout maksimal 3 detik.")

    def drain(self):
        try:
            while True:
                kind, data = self.events.get_nowait()
                if kind == "values":
                    stamp, obj, addresses, values, mode = data
                    for i, value in enumerate(values):
                        row = (stamp, mode, obj, addresses[i], value, f"0x{value:04X}")
                        self.rows.append(row)
                        self.table.insert("", "end", values=row)
                    # Batas memori untuk sesi cyclic panjang; ekspor hanya 5000 baris terakhir.
                    self.rows[:] = self.rows[-5000:]
                    children = self.table.get_children()
                    if len(children) > 5000:
                        self.table.delete(*children[:-5000])
                    self.table.yview_moveto(1)
                    self.status.set(f"{mode} • {stamp} • {len(values)} nilai mentah • maksimal 5000 baris.")
                elif kind == "status":
                    self.status.set(data)
                elif kind == 'confirm_write':
                    self.confirm_write(*data)
                elif kind == 'write_result':
                    target, result = data
                    host, port, name, obj, address, value = target
                    actual = result['readback']
                    if actual is not None:
                        row = (datetime.now().astimezone().isoformat(timespec='seconds'),
                               'LIVE baca ulang write', name, address, actual, f'0x{actual:04X}')
                        self.rows.append(row)
                        self.table.insert('', 'end', values=row)
                        self.rows[:] = self.rows[-5000:]
                        children = self.table.get_children()
                        if len(children) > 5000:
                            self.table.delete(*children[:-5000])
                        self.table.yview_moveto(1)
                    if actual == value and result['acknowledged']:
                        text = f'ACK diterima; baca ulang {name}[{address}] = {actual}, sesuai nilai yang diminta.'
                    elif actual is not None:
                        text = (f'Baca ulang {name}[{address}] = {actual}; diminta {value}. '
                                + ('ACK tidak terkonfirmasi. ' if not result['acknowledged'] else 'Nilai tidak cocok. '))
                    else:
                        text = 'Hasil write belum terkonfirmasi; baca ulang gagal/dihentikan. Jangan anggap write gagal diterapkan.'
                    if result['ack_error']:
                        text += f" Detail ACK: {result['ack_error']}"
                    if result['readback_error']:
                        text += f" Detail baca ulang: {result['readback_error']}"
                    self.status.set(text)
                elif kind == "done":
                    self.set_busy(False)
        except queue.Empty:
            pass
        self.root.after(100, self.drain)

    def export(self):
        if not self.rows:
            messagebox.showinfo("CSV", "Belum ada data.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="SETEX_DATA.csv",
                                          filetypes=[("CSV", "*.csv")])
        if path:
            try:
                with open(path, "w", newline="", encoding="utf-8-sig") as handle:
                    writer = csv.writer(handle)
                    writer.writerow(["waktu", "sumber", "objek", "alamat", "raw", "hex"])
                    writer.writerows(self.rows)
                self.status.set(f"CSV disimpan: {path}")
            except OSError as exc:
                messagebox.showerror("Gagal menyimpan", str(exc))

    def close(self):
        self.stop_event.set()
        self.root.destroy()


if __name__ == "__main__":
    root = tk.Tk()
    App(root)
    root.mainloop()
