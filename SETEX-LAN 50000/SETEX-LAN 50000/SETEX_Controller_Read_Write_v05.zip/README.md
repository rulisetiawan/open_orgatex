# SETEX Controller v0.5 — Read / Write

Tutup jendela lama lalu jalankan JALANKAN_CONTROLLER_V05.bat (atau JALANKAN.bat).
Judul baru: SETEX Controller v0.5 - Read / Write.
Default IP 172.16.120.113, port 50000. Python 3.10+ dengan tkinter;
tidak membutuhkan paket pip untuk menjalankan aplikasi.

## Write satu alamat

1. Pilih LIVE Controller dan objek IW, ACT, SET, LW, atau MW.
2. Pilih Satuan, isi satu alamat saja, lalu pilih Sekali.
3. Isi Nilai mentah baru (0..65535), bilangan bulat desimal.
4. Klik Baca nilai lama → Konfirmasi write.
5. Dialog menampilkan IP/port, objek/ID, alamat, nilai lama, nilai baru dan hex.
   Pilih Ya untuk mengirim atau Tidak untuk membatalkan.
6. Aplikasi membaca nilai lama kembali. Jika berubah selama konfirmasi,
   write dibatalkan agar Anda dapat memeriksa dan mengonfirmasi ulang.
7. SV_WRITE dikirim satu kali, lalu alamat yang sama dibaca ulang.

Tombol Mulai baca tetap hanya membaca. Pilihan Perintah mengatur pembacaan;
tombol write terpisah selalu memakai SV_WRITE (2).

Nilai adalah uint16 mentah, belum konversi °C, persen, faktor skala, atau
bilangan signed. Arti dan izin alamat tergantung program PLC mesin.
ACT atau register lain dapat ditimpa kembali oleh program PLC; baca ulang
hanya menggambarkan nilai pada saat itu. Pemeriksaan nilai lama bukan operasi
compare-and-swap atomik di PLC; nilai masih bisa berubah setelah pemeriksaan.

Versi ini tidak menyediakan write blok, daftar, cyclic, bit, retry, rollback,
atau pengembalian nilai lama otomatis. Stop sebelum pengiriman membatalkan;
setelah write dikirim Stop tidak dapat menarik kembali perintahnya.

## Arti hasil write

- ACK diterima + baca ulang cocok: respons write lolos pemeriksaan dan nilai
  hasil baca sama dengan yang diminta pada saat itu.
- Nilai baca ulang berbeda: aplikasi menampilkan nilai aktual, bukan memaksa
  hasil menjadi nilai yang diminta.
- Timeout / ACK tidak valid: hasil write belum pasti. Perintah mungkin sudah
  diterapkan. Tidak ada pengiriman ulang otomatis; aplikasi mencoba baca ulang.
- Baca ulang gagal/dihentikan: hasil belum terkonfirmasi. Jangan menyimpulkan
  mesin tidak berubah hanya karena aplikasi menampilkan error.

## Membaca data

Pilih SV_READ, objek, alamat, Sekali atau Cyclic, lalu Mulai baca.
Tulis 10,20,30,40 untuk alamat terpisah; kolom jumlah dan pilihan Satuan/
Lebih dari 1 diabaikan ketika ada koma. Daftar dibaca satu per satu dengan
jeda 1 detik. Untuk rentang, tulis alamat awal dan pilih Lebih dari 1 serta
jumlah. SV_READ_BLOCK hanya untuk rentang berurutan, maksimal 80 alamat.
Interval cyclic minimal 1 detik setelah satu siklus selesai.

| Objek | ID | Arti |
| --- | --- | --- |
| IW | 1025 | Info Words |
| ACT / IST | 1010 | Nilai aktual |
| SET / SOLL | 1009 | Nilai target/setpoint |
| LW | 1001 | Link Words |
| MW | 1058 | Memory Words |

Alamat masing-masing objek terpisah: ACT 1 tidak berarti sensor yang sama
dengan IW 1. Menu SET adalah kelompok data target, bukan perintah write.

Mode SIMULASI hanya untuk pembacaan angka buatan dan diberi label pada tabel
serta CSV. Tidak ada fallback dari LIVE ke angka simulasi. Decoder bit dan
SV_READ_LIST LIVE belum diimplementasikan.

## Koneksi, log, dan validasi

Tes TCP saja membuka/menutup koneksi tanpa payload aplikasi. Aplikasi tidak
menghubungi jaringan saat dibuka. Semua koneksi dilakukan setelah aksi Anda.
controller_packets.jsonl mencatat TX/RX, waktu, IP/port, termasuk balasan parsial.
Ekspor CSV menyimpan maksimal 5000 baris terakhir; baris hasil baca ulang write
ditandai LIVE baca ulang write. Arsipkan log saat aplikasi berhenti bila membesar.

Implementasi Controller masih eksperimental, hasil penelusuran statis DLL 6A:
- RCClient.ini: Controller_Port=50000, RCServer_Port=50010.
- Commands.csv: SV_READ (1), SV_WRITE (2), SV_READ_BLOCK (11) untuk objek word.
- Api_ReadPLCWord/Words: payload alamat uint16 / alamat+jumlah uint16.
- Api_WritePLCWord → fungsi internal RVA 0x17474 pada
  SecomCE_D_BackGround_2d.dll: service 2, panjang payload 4, alamat uint16
  pada offset 20, nilai uint16 pada offset 22.
- SecomCE_TCP_2d.dll mengirim frame tetap 516 byte. Header panjang data berada
  di offset 18, payload mulai offset 20. Format ini berbeda dari campuran
  header 74 byte pada dokumen perencanaan awal.
- Balasan diperiksa magic, panjang, jenis respons, service, dan object ID.
  Format ACK write pada mesin target masih harus diverifikasi melalui pengujian.

Validasi lokal: python -m unittest -v; 21 tes lulus. Termasuk layout write,
penolakan nilai invalid, batal konfirmasi, nilai lama berubah, stop sebelum
pengiriman, sekali kirim tanpa retry saat timeout, dan baca ulang gagal.
Respons pengujian dibuat lokal. Pengembang tidak melakukan write ke PLC fisik.
