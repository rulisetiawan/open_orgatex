import math
import struct
import threading
import unittest
from unittest.mock import patch
from setex_controller import ProtocolError
from setex_intervent import (FunctionSnapshot, function_frame, decode_function,
                             changed_values, change_temperature_once, PARAMETERS, parameter_rows)


class InterventTests(unittest.TestCase):
    def snapshot(self):
        return FunctionSnapshot(0, 141, (45., 1., 2., 0., 0., 0.), (3, 4, 5, 0, 0, 0))

    def reply(self, service=1, values=None):
        values = values or self.snapshot().values
        frame = bytearray(function_frame(106, 0, values))
        frame[14] = 2
        frame[15] = service
        for i, pid in enumerate((3, 4, 5, 0, 0, 0)):
            struct.pack_into('<H', frame, 29 + 8*i, pid)
        return bytes(frame)

    def test_api_read_function_layout(self):
        frame = function_frame(1)
        self.assertEqual(len(frame), 516)
        self.assertEqual(struct.unpack_from('<HH', frame), (2, 80))
        self.assertEqual(frame[14:23], bytes.fromhex('01 01 06 00 40 00 00 8d 00'))
        self.assertEqual(frame[23:], bytes(493))

    def test_function_roundtrip_and_preserved_other_values(self):
        snapshot = decode_function(self.reply())
        self.assertEqual(snapshot, self.snapshot())
        values = changed_values(snapshot, next(iter(PARAMETERS)), 50.)
        self.assertEqual(values, (50., 1., 2., 0., 0., 0.))
        frame = function_frame(106, 0, values)
        self.assertEqual(frame[15], 106)
        self.assertEqual(struct.unpack_from('<f', frame, 25)[0], 50.)
        self.assertEqual(struct.unpack_from('<f', frame, 33)[0], 1.)
        self.assertEqual(struct.unpack_from('<f', frame, 41)[0], 2.)

    def test_reject_wrong_function_size_and_nonfinite(self):
        for offset, value in [(16, 41), (18, 0), (21, 142), (20, 7)]:
            bad = bytearray(self.reply())
            bad[offset] = value
            with self.subTest(offset=offset), self.assertRaises(ProtocolError):
                decode_function(bytes(bad))
        bad = bytearray(self.reply())
        struct.pack_into('<f', bad, 25, math.nan)
        with self.assertRaises(ProtocolError):
            decode_function(bytes(bad))

    def test_config_bounds(self):
        for name, value in [('P1 - Suhu (°C)', 151), ('P2 - Gradien (°C/min)', -1),
                            ('P3 - Waktu (min)', 181), ('P1 - Suhu (°C)', math.nan)]:
            with self.assertRaises(ValueError):
                changed_values(self.snapshot(), name, value)

    def test_changed_snapshot_never_sends_change(self):
        other = FunctionSnapshot(0, 141, (46., 1., 2., 0., 0., 0.))
        with patch('setex_intervent.read_temperature', return_value=other), patch('setex_intervent._exchange') as exchange:
            with self.assertRaises(ProtocolError):
                change_temperature_once('127.0.0.1', 50000, self.snapshot(), next(iter(PARAMETERS)), 50., threading.Event())
            exchange.assert_not_called()

    def test_sends_once_and_reads_back(self):
        after = FunctionSnapshot(0, 141, (50., 1., 2., 0., 0., 0.))
        with patch('setex_intervent.read_temperature', side_effect=[self.snapshot(), after]), patch('setex_intervent._exchange', return_value=self.reply(106)) as exchange:
            result = change_temperature_once('127.0.0.1', 50000, self.snapshot(), next(iter(PARAMETERS)), 50., threading.Event())
            exchange.assert_called_once()
            self.assertEqual(exchange.call_args.args[2][15], 106)
            self.assertTrue(result['acknowledged'])
            self.assertEqual(result['readback'], after)

    def test_timeout_has_no_retry(self):
        with patch('setex_intervent.read_temperature', return_value=self.snapshot()), patch('setex_intervent._exchange', side_effect=TimeoutError('timeout')) as exchange:
            result = change_temperature_once('127.0.0.1', 50000, self.snapshot(), next(iter(PARAMETERS)), 50., threading.Event())
            exchange.assert_called_once()
            self.assertFalse(result['acknowledged'])
            self.assertEqual(result['ack_error'], 'timeout')
            self.assertEqual(result['readback'], self.snapshot())

    def test_drain_profile_and_preserve_drain_code(self):
        frame = bytearray(function_frame(106, 0, (0., 1., 2., 0., 0., 0.), 71))
        frame[14:16] = bytes((2, 1))
        for i, pid in enumerate((6, 16, 18)):
            struct.pack_into('<H', frame, 29 + 8*i, pid)
        snapshot = decode_function(bytes(frame), 71)
        self.assertEqual(snapshot.function_id, 71)
        values = changed_values(snapshot, 'P1 - Level akhir (%)', 5.)
        self.assertEqual(values, (5., 1., 2., 0., 0., 0.))
        with self.assertRaises(ValueError):
            changed_values(snapshot, 'P2 - Kode drain', 2.)
        with self.assertRaises(ProtocolError):
            decode_function(bytes(frame), 141)

    def test_error_62_is_decoded(self):
        frame = bytearray(function_frame(106, 0, self.snapshot().values))
        frame[14] = 3
        struct.pack_into('<H', frame, 2, 20)
        struct.pack_into('<HH', frame, 16, 6, 4)
        struct.pack_into('<HH', frame, 20, 19, 62)
        from setex_controller import validate_response
        with self.assertRaisesRegex(ProtocolError, 'error 62 — Invalid status'):
            validate_response(bytes(frame), 106, 6)

    def test_fill_liter_profile_reads_but_no_changes_without_limits(self):
        frame = bytearray(function_frame(1, function_id=713))
        frame[14] = 2
        struct.pack_into('<f', frame, 25, 1.)
        struct.pack_into('<f', frame, 33, 8000.)
        snapshot = decode_function(bytes(frame), 713)
        self.assertEqual(snapshot.values[:2], (1., 8000.))
        with self.assertRaises(ValueError):
            changed_values(snapshot, 'P2 - Volume (L)', 9000.)

    def test_six_rows_and_unused_slots(self):
        rows = parameter_rows(self.snapshot())
        self.assertEqual(len(rows), 6)
        self.assertEqual(rows[0][:3], ('P1', 3, 'Suhu target'))
        self.assertEqual(rows[2][1], 5)
        self.assertIsNone(rows[3][-1])

    def test_changed_parameter_id_cannot_be_written(self):
        snapshot = FunctionSnapshot(0, 141, (45., 1., 2., 0., 0., 0.), (9, 4, 5, 0, 0, 0))
        self.assertEqual(parameter_rows(snapshot)[0][2], 'Volume isi')
        self.assertIsNone(parameter_rows(snapshot)[0][-1])
        with self.assertRaises(ValueError):
            changed_values(snapshot, 'P1 - Suhu (°C)', 50.)


if __name__ == '__main__':
    unittest.main()
