"""Experimental function-level intervention, reconstructed from 13E HMI APIs.

Profiles Temperature Control 141 and Drain Percent 71; no parameter-41 guesses.
"""
import math
import struct
from dataclasses import dataclass
from setex_controller import build_read, validate_response, _exchange, ProtocolError

FUNCTION_ID = 141
PARAMETERS = {
    'P1 - Suhu (°C)': (0, 0.0, 150.0),
    'P2 - Gradien (°C/min)': (1, 0.0, 9.9),
    'P3 - Waktu (min)': (2, 0.0, 180.0),
}
FUNCTIONS = {'141 - Temperature Control': 141, '71 - Drain Percent': 71}
PROFILE_PARAMETERS = {
    141: PARAMETERS,
    71: {'P1 - Level akhir (%)': (0, 0.0, 100.0),
         'P3 - Waktu (min)': (2, 0.0, 180.0)},
}


@dataclass(frozen=True)
class FunctionSnapshot:
    line: int
    function_id: int
    values: tuple


def function_frame(service, line=0, values=None, function_id=FUNCTION_ID):
    if function_id not in PROFILE_PARAMETERS:
        raise ValueError('Fungsi belum didukung profil 13E.')
    if service not in (1, 106) or type(line) is not int or not 0 <= line <= 6:
        raise ValueError('Service fungsi atau baris fungsi tidak valid.')
    if service == 106 and (values is None or len(values) != 6 or
                           any(not math.isfinite(v) for v in values)):
        raise ValueError('Perubahan fungsi membutuhkan enam nilai finite dari pembacaan sebelumnya.')
    frame = bytearray(build_read(1, 1025, 1))
    frame[20:] = bytes(len(frame) - 20)
    frame[15] = service
    struct.pack_into('<HH', frame, 16, 6, 64)
    struct.pack_into('<H', frame, 2, 80)
    frame[20] = line
    struct.pack_into('<H', frame, 21, function_id)
    if service == 106:
        for i, value in enumerate(values):
            struct.pack_into('<f', frame, 25 + 8 * i, value)
    # Matches Api_Rem_ReadFunction / Api_ChangeFunction builder; fields not
    # provided by those HMI calls remain zero (not copied from opaque response).
    return bytes(frame)


def decode_function(frame, function_id=FUNCTION_ID):
    size = validate_response(frame, 1, 6)
    if size != 64:
        raise ProtocolError(f'Layout fungsi tidak cocok: payload {size}, diharapkan 64. Lihat log.')
    line = frame[20]
    fid = struct.unpack_from('<H', frame, 21)[0]
    values = tuple(struct.unpack_from('<f', frame, 25 + 8*i)[0] for i in range(6))
    if fid != function_id or fid not in PROFILE_PARAMETERS or not 0 <= line <= 6 or any(not math.isfinite(v) for v in values):
        raise ProtocolError('Respons bukan fungsi yang diminta / konteks atau nilai tidak valid.')
    for index, minimum, maximum in PROFILE_PARAMETERS[fid].values():
        if not minimum <= values[index] <= maximum + 0.00001:
            raise ProtocolError('Nilai fungsi di luar batas konfigurasi 13E; perubahan diblokir.')
    return FunctionSnapshot(line, fid, values)


def read_temperature(host, port, stop, function_id=FUNCTION_ID):
    return decode_function(_exchange(host, port, function_frame(1, function_id=function_id), stop), function_id)


def changed_values(snapshot, parameter, new_value):
    if snapshot.function_id not in PROFILE_PARAMETERS or len(snapshot.values) != 6:
        raise ValueError('Snapshot fungsi tidak valid.')
    parameters = PROFILE_PARAMETERS[snapshot.function_id]
    if parameter not in parameters:
        raise ValueError('Parameter tidak dikenali.')
    index, minimum, maximum = parameters[parameter]
    if not math.isfinite(new_value) or not minimum <= new_value <= maximum:
        raise ValueError(f'Nilai harus {minimum:g}..{maximum:g} dalam satuan tampilan.')
    values = list(snapshot.values)
    values[index] = new_value
    return tuple(values)


def change_temperature_once(host, port, snapshot, parameter, value, stop):
    values = changed_values(snapshot, parameter, value)
    request = function_frame(106, snapshot.line, values, snapshot.function_id)
    current = read_temperature(host, port, stop, snapshot.function_id)
    if current != snapshot:
        raise ProtocolError('Parameter/konteks fungsi berubah sejak konfirmasi. Baca dan konfirmasi ulang.')
    if stop.is_set():
        raise InterruptedError('Perubahan dibatalkan sebelum pengiriman.')
    result = dict(acknowledged=False, ack_error=None, readback=None, readback_error=None)
    try:
        response = _exchange(host, port, request, stop)
        validate_response(response, 106, 6)
        result['acknowledged'] = True
    except (OSError, RuntimeError) as exc:
        result['ack_error'] = str(exc)
    if stop.is_set():
        result['readback_error'] = 'Dihentikan; perintah yang sudah dikirim tidak dapat ditarik kembali.'
        return result
    try:
        result['readback'] = read_temperature(host, port, stop, snapshot.function_id)
    except (OSError, RuntimeError) as exc:
        result['readback_error'] = str(exc)
    return result
